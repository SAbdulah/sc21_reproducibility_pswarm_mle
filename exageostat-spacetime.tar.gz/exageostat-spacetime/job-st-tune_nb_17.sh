#!/bin/bash
#SBATCH --job-name=uni-ST
#SBATCH --output=./tune-ts-%A.out
#SBATCH -A k1339
#SBATCH --nodes=17
#SBATCH --ntasks=17
#SBATCH --partition=workq
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=32
#SBATCH --time=02:00:00

export STARPU_SCHED=eager

export STARPU_WATCHDOG_TIMEOUT=1000000000
export STARPU_WATCHDOG_CRASH=1


#PARAMETER ESTIMATION


for ts in 320 360 440 460 560 760 960     #640000 #490000 #360000 #40000    90000   160000  250000  360000
do
	echo "srun  --hint=nomultithread numactl  --interleave=all ./build/examples/synthetic_dmle_test_pswarm --ncores=30 --computation=exact --kernel=1:0.23:1:1:0.5:0.5:0 --ikernel=1:0.23:1:1:0.5:0.5:0 --olb=0.0001:0.0001:0.0001:0.0001:0.0001:0.0001:0.0001 --oub=3:3:3:3:1:1:3 --test --N=400 --dts=$ts --p=4 --q=4 --zvecs=1  --kernel_fun="univariate_spacetime_matern_stationary" --opt_tol=7 --dim=st --time_slots=100 --verbose --opt_iters=1
"

	srun  --hint=nomultithread numactl  --interleave=all ./build/examples/synthetic_dmle_test_pswarm --ncores=30 --computation=exact --kernel=1:0.23:1:1:0.5:0.5:0 --ikernel=1:0.23:1:1:0.5:0.5:0 --olb=0.0001:0.0001:0.0001:0.0001:0.0001:0.0001:0.0001 --oub=3:3:3:3:1:1:3 --test --N=400 --dts=$ts --p=4 --q=4 --zvecs=1  --kernel_fun="univariate_spacetime_matern_stationary" --opt_tol=7 --dim=st --time_slots=100 --verbose --opt_iters=1
done
