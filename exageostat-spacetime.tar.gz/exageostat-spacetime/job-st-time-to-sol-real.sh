#!/bin/bash
#SBATCH --job-name=real-uni-ST
#SBATCH --output=./output/%A.out
#SBATCH -A k1339
#SBATCH --nodes=1025
#SBATCH --ntasks=1025
#SBATCH --partition=workq
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=32
#SBATCH --time=23:00:00

export STARPU_SCHED=eager

export STARPU_WATCHDOG_TIMEOUT=1000000000
export STARPU_WATCHDOG_CRASH=1

export STARPU_LIMIT_MAX_SUBMITTED_TASKS=40000
export STARPU_LIMIT_MIN_SUBMITTED_TASKS=30000

#PARAMETER ESTIMATION

echo "srun  --hint=nomultithread numactl  --interleave=all ./build/examples/real_csv_dmle_test_pswarm   --ncores=30   --computation=exact    --kernel=?:?:?:?:?:0:0 --olb=0.0001:0.0001:0.0001:0.0001:0.0001:0.0001:0.0001 --oub=3:3:3:3:1:1:3   --dts=960  --p=16 --q=16 --verbose  --kernel_fun="univariate_spacetime_matern_stationary" --obs_dir=./Data/SC21_DATA/data_st_training_FULL   --locs_file=./Data/SC21_DATA/locations_space_training_FULL  --time_file=./Data/SC21_DATA/locations_time_training_FULL   --dim=st --actualZ_file=./Data/SC21_DATA/data_st_testing_FULL   --actualZloc_file=./Data/SC21_DATA/locations_space_testing_FULL   --actualtime_file=./Data/SC21_DATA/locations_time_testing_FULL"


STARPU_SILENT=1 srun  --hint=nomultithread numactl  --interleave=all ./build/examples/real_csv_dmle_test_pswarm   --ncores=30   --computation=exact    --kernel=?:?:?:?:?:0:0 --olb=0.0001:0.0001:0.0001:0.0001:0.0001:0.0001:0.0001 --oub=3:3:3:3:1:1:3   --dts=960  --p=16 --q=16 --verbose  --kernel_fun="univariate_spacetime_matern_stationary" --obs_dir=./Data/SC21_DATA/data_st_training_FULL   --locs_file=./Data/SC21_DATA/locations_space_training_FULL  --time_file=./Data/SC21_DATA/locations_time_training_FULL   --dim=st --actualZ_file=./Data/SC21_DATA/data_st_testing_FULL   --actualZloc_file=./Data/SC21_DATA/locations_space_testing_FULL   --actualtime_file=./Data/SC21_DATA/locations_time_testing_FULL











