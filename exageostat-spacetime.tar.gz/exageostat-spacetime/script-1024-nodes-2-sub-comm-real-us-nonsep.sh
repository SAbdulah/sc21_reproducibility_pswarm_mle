#!/bin/bash
#SBATCH --job-name=separable-with-non-separable
#SBATCH --output=./output/%A.out
#SBATCH -A k1339
#SBATCH --nodes=1024
#SBATCH --ntasks=1024
#SBATCH --partition=workq
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=32
#SBATCH --time=23:00:00

export STARPU_SCHED=eager

export STARPU_WATCHDOG_TIMEOUT=1000000000
export STARPU_WATCHDOG_CRASH=1

x=50000
y=30000

export STARPU_LIMIT_MAX_SUBMITTED_TASKS=$x
export STARPU_LIMIT_MIN_SUBMITTED_TASKS=$y



# two mpi-sub-communicators 
srun -N 512  --hint=nomultithread numactl  --interleave=all ./build/examples/real_csv_dmle_test_pswarm   --ncores=30   --computation=exact    --kernel=?:?:?:?:?:?:0 --olb=0.0001:0.0001:0.0001:0.0001:0.0001:0.0001:0.0001 --oub=3:3:3:10:1:1:3   --dts=760  --p=32 --q=16 --verbose  --kernel_fun="univariate_spacetime_matern_stationary" --obs_dir=./Data/data_st_training_FULL_US   --locs_file=./Data/locations_space_training_FULL_US  --time_file=./Data/locations_time_training_FULL_US   --dim=st --actualZ_file=./Data/data_st_testing_FULL_US   --actualZloc_file=./Data/locations_space_testing_FULL_US   --actualtime_file=./Data/locations_time_testing_FULL_US --mspe
