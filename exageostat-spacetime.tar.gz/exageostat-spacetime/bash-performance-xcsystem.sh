ts=320    #best tile size
target_theta="1:0.23:1:1:0.5:0.5:0"
for i in 1 2 3			# Three runs
do
	n=400			# Number of spatial locations
	p=4			# number of nodes (in rows) with The Two-dimensional Block-Cyclic Distribution (https://www.netlib.org/scalapack/slug/node75.html)
	q=4			# number of nodes (in cols) with The Two-dimensional Block-Cyclic Distribution (https://www.netlib.org/scalapack/slug/node75.html)
	sbatch job-st-perf-syn-33.sh $n $p $q $ts $target_theta	  #script for 33 nodes performance (32 nodes + 1 node for the PSwarm algorithm)
	sbatch job-st-perf-syn-49.sh $n $p $q $ts $target_theta	  #script for 49 nodes performance (48 nodes + 1 node for the PSwarm algorithm)
	sbatch job-st-perf-syn-65.sh $n $p $q $ts $target_theta	  #script for 65 nodes performance (64 nodes + 1 node for the PSwarm algorithm)
	sbatch job-st-perf-syn-97.sh $n $p $q $ts $target_theta	  #script for 97 nodes performance (96 nodes + 1 node for the PSwarm algorithm)
        sbatch job-st-perf-syn-1025.sh $n $p $q $ts $target_theta #script for 1025 nodes performance (1024 nodes + 1 node for the PSwarm algorithm)

	n=900
	p=4
	q=4
	sbatch job-st-perf-syn-33.sh $n $p $q $ts $target_theta
	sbatch job-st-perf-syn-49.sh $n $p $q $ts $target_theta
	sbatch job-st-perf-syn-65.sh $n $p $q $ts $target_theta
	sbatch job-st-perf-syn-97.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-1025.sh $n $p $q $ts $target_theta

	n=1600
	p=4
	q=4
        sbatch job-st-perf-syn-33.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-49.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-65.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-97.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-1025.sh $n $p $q $ts $target_theta

	n=2500
	p=8
	q=4
        sbatch job-st-perf-syn-33.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-49.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-65.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-97.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-1025.sh $n $p $q $ts $target_theta

	n=3600
	p=8
	q=4
        sbatch job-st-perf-syn-33.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-49.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-65.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-97.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-1025.sh $n $p $q $ts $target_theta

	n=4900
	p=8
	q=4
        sbatch job-st-perf-syn-33.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-49.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-65.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-97.sh $n $p $q $ts $target_theta
        sbatch job-st-perf-syn-1025.sh $n $p $q $ts $target_theta
done
