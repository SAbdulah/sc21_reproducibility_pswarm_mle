#!/bin/bash
#SBATCH --job-name=uni-ST
#SBATCH --output=./output2/%A.out
#SBATCH --nodes=1025
#SBATCH --ntasks=1025
#SBATCH --partition=workq
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=32
#SBATCH --time=02:00:00

export STARPU_SCHED=eager

export STARPU_WATCHDOG_TIMEOUT=1000000000
export STARPU_WATCHDOG_CRASH=1


#PARAMETER ESTIMATION

n=$1
p=$2
q=$3
ts=$4
target_theta=$5

echo "srun  --hint=nomultithread numactl  --interleave=all ./build/examples/synthetic_dmle_test_pswarm --ncores=30 --computation=exact --kernel=$target_theta --ikernel=1:0.23:1:1:0.5:0.5:0 --olb=0.0001:0.0001:0.0001:0.0001:0.0001:0.0001:0.0001 --oub=3:3:3:3:1:1:3 --test --N=$n --dts=$ts --p=$p --q=$q --zvecs=1  --kernel_fun="univariate_spacetime_matern_stationary" --opt_tol=7 --dim=st --time_slots=100 --verbose --opt_iters=100
"

srun  --hint=nomultithread numactl  --interleave=all ./build/examples/synthetic_dmle_test_pswarm --ncores=30 --computation=exact --kernel=$target_theta --ikernel=1:0.23:1:1:0.5:0.5:0 --olb=0.0001:0.0001:0.0001:0.0001:0.0001:0.0001:0.0001 --oub=3:3:3:3:1:1:3 --test --N=$n --dts=760 --p=$ts --q=$q --zvecs=1  --kernel_fun="univariate_spacetime_matern_stationary" --opt_tol=7 --dim=st --time_slots=100 --verbose --opt_iters=100

