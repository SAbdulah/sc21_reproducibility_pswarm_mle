/**
 *
 * Copyright (c) 2017-2020  King Abdullah University of Science and Technology
 * All rights reserved.
 *
 * ExaGeoStat is a software package provided by KAUST
 **/
/**
 *
 * @file synthetic_dmle_test_pswarm.c
 *
 * A complete example to test ExaGeoStat supported function (i.e., dataset generator, Maximum Likelihood Function (MLE), Prediction)
 *
 * @version 1.1.0
 *
 * @author Sameh Abdulah
 * @date 2020-12-30
 *
 **/
#include "examples.h"
#include "../src/include/MLE.h"
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <signal.h>
#include <setjmp.h>
#include <math.h>
#include <sys/types.h>
#ifdef linux
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#endif
#include <sys/stat.h>
#include <fcntl.h>


#include "pswarm_main.h"
#include "pswarm.h"


#ifdef MPE
/* for MPE */
int ComputeID_begin, ComputeID_end, SendID_begin, SendID_end, RecvID_begin,
    RecvID_end;
#endif

MPI_Comm new_comm;
typedef struct { char *msg; } Exit_code;
extern struct Stats stats;

//copied from user.c

extern struct Stats stats;



/**********************************************/
/*                                            */
/* User defined global variables              */
/*                                            */
/**********************************************/

# define DIM 7 /* a linear problem with 6 varibles */
# define CONS 5 /* a linear problem with 5 linear constraints */
double obj_coef[DIM]; /* objective function coefficients */


//*********************************************

static Exit_code exit_codes[] = {
	{"Normal exit"},                /* 0 */
	{"Abnormal exit"},              /* 1 */
	{"Failed to allocate memory"},  /* 2 */
	{"Unable to initalize population"},  /* 3 */
};

extern void *pswarm_malloc(size_t size);


void objfun(int, int, double *, double *, double *, double *);

#if defined(CHAMELEON_USE_MPI)
void MPI_objfun_deamon(MLE_data * data, int n, int m,  double *lb, double *ub, int alg_rank, int new_id, int MPI_myrank)
{
	int action=1, particle;
	double fx, x[n];
	MPI_Status status;
	do {
		if( new_id == 0)
		{
			int MPI_myrank;
			MPI_Comm_rank(MPI_COMM_WORLD, &MPI_myrank);
			//fprintf(stderr, "I am (%d) receiving from : %d", MPI_myrank, alg_rank);
			MPI_Recv(&action, 1, MPI_INT, alg_rank, 99, MPI_COMM_WORLD, &status);
			//fprintf(stderr, ", action is : %d", action);
		}
		MPI_Bcast(&action, 1, MPI_INT, 0, new_comm );
		if(action){ /* Objective function request */
			if( new_id == 0)
			{

				if(action==2)
					MPI_Recv(&particle, 1, MPI_INT, alg_rank, 99, MPI_COMM_WORLD, &status);
			//fprintf(stderr, ", action = %d ", action);
				MPI_Recv(&x, n, MPI_DOUBLE, alg_rank, 99, MPI_COMM_WORLD, &status);
                        //fprintf(stderr, ",/n YYYYYYYYYYYYYYYYYYYYYYYYYY = %d ", action);
				//fprintf(stderr, "...Done \n");
				//int z=0;
				//for(z=0;z<n;z++)
				//fprintf(stderr, "%f\n", x[z]);
				//fprintf(stderr, "alg_rank: %d \n", alg_rank);

			}
			//fprintf(stderr, "*******************************alg_rank: %d \n", alg_rank);
			MPI_Bcast(&x, n, MPI_DOUBLE, 0, new_comm );
			//fprintf(stderr, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@alg_rank: %d \n", alg_rank);
			objfun_mle(data, n,  m, x,   lb, ub, &fx);
			//fprintf(stderr, "==========================alg_rank: %d \n", alg_rank);
			stats.objfunctions++;
			if( new_id == 0)
			{
				//fprintf(stderr, "^^^^^^^^^^^^^^^^^^^^^^^^^^^^alg_rank: %d \n", alg_rank);
				if(action==2)
					MPI_Send(&particle, 1, MPI_INT, alg_rank, 99, MPI_COMM_WORLD);
				MPI_Send(&fx, 1, MPI_DOUBLE, alg_rank, 99, MPI_COMM_WORLD);
				//fprintf(stderr, ", action2 = %d ", action);
			}
			//fprintf(stderr, "--------------------------alg_rank: %d \n", alg_rank);
		}

		//        fprintf(stderr, ", action2 = %d \n", action);
	} while(action);

	return;
}
#endif

int PSwarm(MLE_data * data, int ncores, int ngpus, int p_grid, int q_grid, int n, int dts, int lts, int zvecs, int N, double * initial_theta, void (*objf)(), double *lb, double *ub, int lincons, double *A, double *b, double **sol, double *f, double *x);

extern struct Options opt;

extern void save_cache_file(int n, int m);
extern void load_cache_file(int n, int m);
extern int read_cesam_cache(int n, double *x, double *age,
		double *teff, double *lum, double *r);
extern void write_cesam_cache(int n, double *x, double *age,
		double *teff, double *lum, double *r);

#ifndef AMPL

extern void set_problem(double *x, double *lb, double *ub, double *A, double *b);
extern void set_problem_dimension(int *n, int *lincons);

#if defined(CHAMELEON_USE_MPI)

void user_init_MPI(int MPI_myrank)
{

	/* use this function if some global data must be initialized */
	obj_coef[0] = -10.0;
	obj_coef[1] = -15.0;
	obj_coef[2] = -22.0;
	obj_coef[3] = -17.0;
	obj_coef[4] = 0.0;
	obj_coef[5] = 0.0;
	obj_coef[6] = 0.0;
}
#else
void user_init()
{

	/* use this function if some global data must be initialized */
	obj_coef[0] = -10.0;
	obj_coef[1] = -15.0;
	obj_coef[2] = -22.0;
	obj_coef[3] = -17.0;
	obj_coef[4] = 0.0;
	obj_coef[5] = 0.0;
	obj_coef[6] = 0.0;

}
#endif
#endif


#ifdef AMPL

static double objsign;
static fint NERROR = -1;
#define asl cur_ASL

char pswarm_version[]="PSwarm v1.4";

/* This struct member name

   keyword keywds[] = {
   KW("cognitial"   , pswarm_opt_d, (Char*)&opt.mu,
   "Cognitial parameter"),
   KW("ddelta"   , pswarm_opt_d, (Char*)&opt.ddelta,
   "Deacresing delta factor (<1)"),
   KW("delta"   , pswarm_opt_d, (Char*)&opt.delta,
   "Initial delta"),
   KW("fweight"   , pswarm_opt_d, (Char*)&opt.fweight,
   "Final weight (inercial parameter)"),
   KW("idelta"   , pswarm_opt_d, (Char*)&opt.idelta,
   "Increase delta factor (>1)"),
   KW("iprint"   , pswarm_opt_i, (Char*)&opt.IPrint,
   "Print for every iprint iterations (<0 no print, =0 print final; >0 print)"),
   KW("iweight"   , pswarm_opt_d, (Char*)&opt.iweight,
   "Initial weight (inercial parameter)"),
   KW("maxf", pswarm_opt_i, (Char*)&opt.maxf,
   "Maximum number of function evaluations times problem dimension"),
   KW("maxit", pswarm_opt_i, (Char*)&opt.maxiter,
   "Maximum number of iterations times problem dimension"),
   KW("size"        , pswarm_opt_i, (Char*)&opt.s,
   "Swarm size"),
   KW("social"        , pswarm_opt_d, (Char*)&opt.nu,
   "Social parameter"),
   KW("tol"        , pswarm_opt_d, (Char*)&opt.tol,
   "Stopping tolerance parameter"),
   KW("vectorized"    , pswarm_opt_i, (Char*)&opt.vectorized,
   "Vectorized call to the objective function"),
   };


   struct Option_Info Oinfo = { "pswarm", "PSwarm", "pswarm_options",
   keywds, nkeywds, 1, pswarm_version, 0, NULL};




/**********************************************
Set options. String type
 **********************************************/
char *pswarm_opt_s(Option_Info *oi, keyword *kw, char *value)
{
	char *s;


	/* never echo options */
	oi->option_echo &= ~ASL_OI_echo;
	if(!strncmp("method", kw->name, 6)){
		s=value;
		while(*s!=' ' && *s!=0)
			s++;
		if(s<=value)
			return value;

		if(!strncmp("disc_hett", value, 9)){
			*(int *)kw->info=0; /*DISC_METHOD;*/
			printf("Discretization method selected Hettich version\n");
			return s;
		}

		/* unknown method */
		return value;
	}


	/* not implemented option */
	return value;
}


/**********************************************
  Set options. Integer type
 **********************************************/
char *pswarm_opt_i(Option_Info *oi, keyword *kw, char *value)
{
	long optval;
	char *s;

	/* never echo options */
	oi->option_echo &= ~ASL_OI_echo;

	optval=strtol(value, &s, 10);
	if(s > value){
		/* existing integer number */
		*(int *)kw->info=(int)optval;
		printf("\nDefault option %s=%d changed\n", kw->name, *(int *)kw->info);
		return s;
	}

	return value;
}


/**********************************************
  Set options. Double type
 **********************************************/

char *pswarm_opt_d(Option_Info *oi, keyword *kw, char *value)
{
	double optval;
	char *s;

	/* never echo options */
	oi->option_echo &= ~ASL_OI_echo;

	optval=strtod(value, &s);

	if(s > value){
		/* existing double number */
		*(double *)kw->info=optval;
		printf("\nDefault option %s=%.6f changed\n", kw->name, *(double *)kw->info);
		return s;
	}

	return value;
}

#endif /* AMPL */


static jmp_buf Jb;

void catchfpe(int n)
{
#ifdef AMPL
	report_where(asl);
#endif /* AMPL */
	printf("\nFloating point error.\n");
	fflush(stdout);
	longjmp(Jb,1);
}
//***********************
int main(int argc, char **argv) {
	arguments arguments;
	int MPI_communicators =0;
	//Arguments default values
	set_args_default(&arguments);
	argp_parse(&argp, argc, argv, 0, 0, &arguments);
	check_args(&arguments);
	//initialization
	double *starting_theta;
	double *target_theta;
	double *initial_theta;  //for testing case
	int num_params = 0;
	int N, dts, lts, log;
	int i = 0;
	int j = 0;
	int p = 0;         //univariate/bivariate/multivariate
	int zvecs = 1, nZmiss = 0, test = 0, gpus = 0;
	double x_max, x_min, y_max, y_min;
	int p_grid, q_grid, ncores;
	double  opt_f;
	double all_time=0.0;
	double pred_time=0.0;
	nlopt_opt opt2;
	MLE_data data;
	int seed = 0;
	location *locations = NULL;
	double prediction_error = 0.0;
	double *lb, *ub;
	double total_time = 0.0;
	int total_mpi_processes = 0;
	int  MPI_myrank=0;
	//****************************************************************************************************
	if(strcmp(arguments.kernel_fun, "univariate_matern_stationary")   == 0)
	{
		num_params    = 3;
		p             = 1;
	}
	else if(strcmp(arguments.kernel_fun, "univariate_matern_nuggets_stationary")   == 0)
	{
		num_params     = 4;
		p              = 1;
	}
	else if(strcmp(arguments.kernel_fun, "univariate_matern_non_stationary")   == 0)
	{
		num_params     = 9;
		p              = 1;
	}
	else if(strcmp(arguments.kernel_fun, "bivariate_matern_flexible")   == 0)
	{
		num_params     = 11;
		p              = 2;
	}
	else if(strcmp(arguments.kernel_fun, "bivariate_matern_parsimonious")   == 0
			|| strcmp(arguments.kernel_fun, "bivariate_matern_parsimonious_profile")   == 0)
	{
		num_params     = 6;
		p              = 2;
	}
	else if(strcmp(arguments.kernel_fun, "bivariate_matern_parsimonious2")   == 0
			|| strcmp(arguments.kernel_fun, "bivariate_matern_parsimonious2_profile") == 0)
	{
		num_params      = 6;
		p               = 2;
	}
	else if(strcmp(arguments.kernel_fun, "univariate_spacetime_matern_stationary")   == 0)
	{
		num_params = 7;
		p          = 1;
	}
	else
	{
		fprintf(stderr,"Choosen kernel is not exist(20)!\n");
		fprintf(stderr, "Called function is: %s\n",__func__);
		exit(0);
	}
	//double* lb = (double *) malloc(num_params * sizeof(double));
	//double* up = (double *) malloc(num_params * sizeof(double));
	//int iseed[4]={seed, seed, seed, 1};

	//Memory allocation
	//starting_theta    = (double *) malloc(num_params * sizeof(double));
	initial_theta   = (double *) malloc(num_params * sizeof(double));
	target_theta    = (double *) malloc(num_params * sizeof(double));
	/* lower and upper bounds on variables */
	lb=pswarm_malloc(num_params*sizeof(double));
	ub=pswarm_malloc(num_params*sizeof(double));

	//starting_theta
	starting_theta=pswarm_malloc(num_params*sizeof(double));
	//MLE_data data initialization
	init(&test, &N,  &ncores,
			&gpus, &p_grid, &q_grid,
			&zvecs, &dts, &lts,
			&nZmiss, &log, initial_theta,
			starting_theta, target_theta, lb,
			ub, &data, &arguments);

	if(strcmp(arguments.dim, "2d") == 0)
	{
		printf("2D example......\n");
		locations = GenerateXYLoc(N/p, seed);
		data.l1.z=NULL;
	}
	else if(strcmp(arguments.dim, "3d") == 0)
	{
		printf("3D example......\n");
		locations = GenerateXYZLoc(N/p, seed);
	}
	else if(strcmp(arguments.dim, "st") == 0)
	{
		printf("ST example......\n");
		locations = GenerateXYLoc_ST(N/p, data.time_slots, seed);
	}
	else
	{
		printf("Input dimension is not supported. Please use 2d, 3d, or st\n\n");
		exit(0);
	}

	data.l1 = *locations;
	data.precision = 0;

	if(strcmp(arguments.kernel_fun, "univariate_spacetime_matern_stationary")   == 0)
		p          = data.time_slots;
	if(strcmp(arguments.kernel_fun, "bivariate_matern_parsimonious2")   == 0
			|| strcmp(arguments.kernel_fun, "bivariate_matern_parsimonious2_profile")   == 0)
	{
		if(N%dts !=0)
		{
			printf("please use N divisible by dts, only with parsimonious2\n");
			exit(0);
		}

	}

	int nZobs = strcmp(data.actualZFPath,"") == 0? (N-nZmiss) : N;
	//To support multivariate case
	N= p*N;
	//****************************************************************************************************
	int exit_code;
	double *sol=NULL;
	double *f=NULL;
	double *A, *b; /* linear constraints defined in a Fortran way */
	int lincons = 0; /* number of linear constraints SAMEH: Zero in our case*/
	//int n;   //SAMEH: num_params
	double *X0; ///SAMEH: starting Theta
	/*
	 * The setjmp() function saves various information about the calling environment (typically, the stack pointer, the instruction pointer, possibly the values of other registers and the signal mask) in the buffer env for later use by longjmp()
	 * */
	if (!setjmp(Jb)){
		signal(SIGFPE, catchfpe);

		//set_problem_dimension(&n,&lincons);
		// n = num_params;// 
		lincons= 0; // Sameh no constraints for our application.
		printf("number of paramters: %d, number of constraints: %d\n", num_params, lincons); //lincons should equal 0

		//***********************************************

		if(!lb || !ub){
			printf("Unable to allocate memory for variable bounds\n");
			exit(1);
		}

		if(!starting_theta){
			printf("Unable to allocate memory for initial guess\n");
			exit(1);
		}
		A=b=NULL;
		//set_problem(X0, lb, ub, A, b);
		for(j=0; j<num_params; j++)
			starting_theta[j] = lb[j];

#if defined(CHAMELEON_USE_MPI)
		//      MPI_Init(&argc,&argv);
		int stop=0,  MPI_numprocs;
		int provided;
		//MPI_Init_thread(&argc,&argv, MPI_THREAD_MULTIPLE, &provided);
		MPI_Init_thread( NULL, NULL, MPI_THREAD_MULTIPLE, &provided );
		MPI_Comm_rank(MPI_COMM_WORLD, &MPI_myrank);
		MPI_Comm_size(MPI_COMM_WORLD, &MPI_numprocs);
		user_init_MPI(MPI_myrank);
		MPI_communicators = MPI_numprocs / (atoi(arguments.p)*atoi(arguments.q));
		int MPI_procs_per_comm = (atoi(arguments.p)*atoi(arguments.q));
		total_mpi_processes = MPI_numprocs-1;
		MPI_numprocs=MPI_communicators;
		fprintf(stderr, "MPI_numprocs:%d\n", MPI_numprocs);
		fprintf(stderr, "MPI_communicators:%d\n", MPI_communicators);
		fprintf(stderr, "MPI_procs_per_comm:%d\n", MPI_procs_per_comm);
		fprintf(stderr, "total_mpi_processes:%d\n", total_mpi_processes);
		MPI_Comm comm;
		int myid = -1;
		int new_id = -1;
		int new_nodes = -1;
		int color = -1;
		MPI_Comm_rank(MPI_COMM_WORLD, &myid);
		//      for (i = 0; i < MPI_communicators; i++)
		//      {
		if (total_mpi_processes == myid)
			//color = MPI_communicators;
			color = MPI_communicators;
		else
			color = myid %MPI_communicators;
		//color = myid % MPI_communicators ;
		MPI_Comm_split(MPI_COMM_WORLD, color, 0, &comm);
		MPI_Comm_rank(comm, &new_id);
		fprintf(stderr, "id: %d, color :%d, new_id:%d\n",
				myid, color, new_id);
		MPI_Comm_size( comm, &new_nodes);
		fprintf(stderr, "new_nodes:%d\n",
				new_nodes);
		morse_set_comm(comm);
		new_comm=comm;
		if(MPI_myrank != total_mpi_processes)
		{
			exageostat_init(&ncores, &gpus, &dts, &lts, comm);
			MPI_Comm_size( comm, &new_nodes);
			int iseed[4]={seed, seed, seed, 1};
			double *Nrand    = (double *) malloc (N * zvecs * sizeof(double));
			LAPACKE_dlarnv(3, iseed, N*zvecs, Nrand);
			MORSE_dmle_Call(&data, ncores, gpus, dts, p_grid, q_grid, N,  N, 0);
			MLE_zvg(&data, &Nrand[0], initial_theta, N, dts, log, p_grid, q_grid);
		}
		//		MPI_Barrier( MPI_COMM_WORLD );
		//		exit(0);
#else
		user_init();
		//Matrix genertaion
		exageostat_init(&ncores, &gpus, &dts, &lts, MPI_COMM_WORLD);
		int iseed[4]={seed, seed, seed, 1};
		double *Nrand    = (double *) malloc (N * zvecs * sizeof(double));
		LAPACKE_dlarnv(3, iseed, N*zvecs, Nrand);
		MORSE_dmle_Call(&data, ncores, gpus, dts, p_grid, q_grid, N,  N, 0);
		MLE_zvg(&data, &Nrand[0], initial_theta, N, dts, log, p_grid, q_grid);
#endif

		START_TIMING(total_time);
#ifdef MPE
		MPE_Init_log();

		ComputeID_begin = MPE_Log_get_event_number();
		ComputeID_end   = MPE_Log_get_event_number();
		SendID_begin    = MPE_Log_get_event_number();
		SendID_end      = MPE_Log_get_event_number();
		RecvID_begin    = MPE_Log_get_event_number();
		RecvID_end      = MPE_Log_get_event_number();
#endif

		data.l1 = *locations;
		data.precision = 0;

		//to be removed
		if(strcmp(data.kernel_fun, "univariate_spacetime_matern_stationary")   == 0)
		{
			starting_theta[0] = 1;
			starting_theta[1] = 1;
			starting_theta[2] = 0.2;
			starting_theta[3] = 1;
			starting_theta[4] = 1;
			starting_theta[5] = 0.22;
		}
#if defined(CHAMELEON_USE_MPI)
		if(MPI_myrank == total_mpi_processes){ /* I am the algorithm */
			fprintf(stderr, "--------------------MPI_myrank: %d,  MPI_numprocs: %d\n", MPI_myrank, total_mpi_processes);
#else
			if(1){
#endif

#ifdef MPE
				MPE_Describe_state(ComputeID_begin, ComputeID_end, "Compute", "red");
				MPE_Describe_state(SendID_begin, SendID_end, "Send", "blue");
				MPE_Describe_state(RecvID_begin, RecvID_end, "Recv", "green");

				MPE_Start_log();
#endif
				//	printf("MPI_myrank= %d\n", MPI_myrank);
				//	//      load_cache_file(n, 4);
				//	printf("******************************************************MPI_myrank= %d\n", MPI_myrank);
				exit_code=PSwarm(&data, ncores, gpus, p_grid, q_grid, num_params,dts, 
						lts, zvecs, N, initial_theta,  &objfun_mle, 
						lb, ub, lincons, A, b, &sol, f, starting_theta);
#if defined(CHAMELEON_USE_MPI)
				/* Goodbye to objective function processes */
				//fprintf(stderr, "MPI_procs_per_comm:....%d\n", MPI_procs_per_comm);
				for(i=0;i<MPI_communicators;i++)
				{
					//fprintf(stderr, "======= I am sending to------ : %d", i);
					MPI_Send(&stop, 1, MPI_INT, i, 99, MPI_COMM_WORLD);
					//fprintf(stderr, ".....Done %d \n", i);
				}
#endif

				//      save_cache_file(n, 4);

				if(opt.IPrint>=0)
					printf("\n%s\n", exit_codes[exit_code].msg);



			} else { /* I am an objective function process */

#if defined(CHAMELEON_USE_MPI)
				int alg_rank = total_mpi_processes;
				stats.objfunctions=0;
				MPI_objfun_deamon(&data, num_params, 1, lb, ub, alg_rank, new_id, MPI_myrank);
				fprintf(stderr, "Deamon %d computed %d objectives\n", MPI_myrank, stats.objfunctions);
#endif

				exit_code=0; /* never executed if not MPI */

			}

#ifdef MPE
			MPE_Finish_log("PPswarm");
#endif

#if defined(CHAMELEON_USE_MPI)
			MPI_Finalize();
#endif

		}

		if(lb)
			free(lb);
		if(ub)
			free(ub);
		if(A)
			free(A);
		if(b)
			free(b);

		STOP_TIMING(total_time);

		if(MPI_myrank == 0)// not the root
		{
			results.time_per_iteration = data.avg_exec_time_per_iter/data.iter_count;
			results.flops_per_iteration = data.avg_flops_per_iter/data.iter_count;
			results.total_mle_time = data.avg_exec_time_per_iter;
			FILE *pFile;
			pFile = fopen("results.log","a");
			fprintf(pFile, "%d, %f, %f, %f\n", results.dense_ts, results.time_per_iteration, (MPI_communicators*results.flops_per_iteration), total_time);
			fclose(pFile);
		}
		//****************************************************************************************************
		if(nZmiss != 0){

			//initialization
			double *Zobs;
			double *Zactual;
			double *Zmiss;
			int i=0;
			double avg_pred_value=0.0;
			double avg_pred_value1=0.0;
			double avg_pred_value2=0.0;
			int pred_samples = 1;
			//for (i=0;i<10;i++)


			if(data.mloe_mmom ==1 || data.mloe_mmom_async ==1)
			{



				nZobs = strcmp(data.actualZFPath,"") == 0? (N/p-nZmiss) : N;
#if defined(EXAGEOSTAT_USE_HICMA)
				if(strcmp (data.computation, "lr_approx") == 0)
					data.hicma_data_type = HICMA_STARSH_PROB_GEOSTAT_POINT;
#endif
				printf("NZobs=%d, nZmiss=%d, N=%d,\n", nZobs, nZmiss, N);
				//exit(0);
				Zobs    = (double *) malloc(nZobs * sizeof(double));
				Zactual = (double *) malloc(nZmiss * sizeof(double));
				if (p==2)
					pick_random_points_noshuffle(&data, Zobs, Zactual, nZmiss, nZobs, N);
				else
					pick_random_points(&data, Zobs, Zactual, nZmiss, nZobs, N);
				mloe_mmom_init(&data, nZmiss, nZobs, dts, p_grid, q_grid);
				START_TIMING(all_time);
				if(data.mloe_mmom ==1)
					MORSE_dmle_mloe_mmom_Tile(&data, initial_theta, starting_theta, nZmiss, nZobs, N);
				if(data.mloe_mmom_async ==1)
					MORSE_dmle_mloe_mmom_Tile_Async(&data, initial_theta, starting_theta, nZmiss, nZobs, N);				
				//TO BE REMOVED
				data.kernel_fun        = arguments.kernel_fun;
				STOP_TIMING(all_time);
				free(Zobs);
				free(Zactual);
				fprintf(stderr," ---- mloe_mmom Time(main): %6.2f seconds\n\n", all_time);
				//	}
				//      mloe_mmom_Finalize(&data);
				MLOE_MMOM_Finalize(&data);
		}




		if(data.idw ==1)
		{
			//memory allocation
			Zobs     = (double *) malloc(p*nZobs * sizeof(double));
			Zactual    = (double *) malloc(p*nZmiss * sizeof(double));
			Zmiss    = (double *) malloc(p*nZmiss * sizeof(double));
			double* mspe     = (double *) malloc(3 * sizeof(double));
			int j = 0;
			for (j = 0; j < pred_samples; j++)
			{
				printf("nZobs = %d\n", p*nZobs);
				if(p==2)
					pick_random_points2(&data, Zobs, Zactual, nZmiss, nZobs, N);
				else
					pick_random_points(&data, Zobs, Zactual, nZmiss, nZobs, N);

				START_TIMING(pred_time);
				//generate_interior_points(&data, Zobs, NULL, nZmiss, nZobs, N);
				mspe = pred_idw(&data, Zmiss, Zactual, Zobs,  nZmiss, nZobs);
				//double prediction_error2 = pred_idw(&data, Zmiss, Zactual, Zobs, p*nZmiss, p*nZobs, 1);
				//#endif
				STOP_TIMING(pred_time);
#if defined(CHAMELEON_USE_MPI)
				if(MORSE_My_Mpi_Rank() == 0)
				{
#endif
					int index=0;
					for (index=0; index< nZmiss; index++)
						printf ("(%3.6f, %3.6f)\n ", Zactual[index], Zmiss[index]);
					fprintf(stderr,"Prediction Error (IDW): %3.9f  -  %3.9f -  %3.9f\n", mspe[0], mspe[1], mspe[2]);
#if defined(CHAMELEON_USE_MPI)
				}
#endif
				avg_pred_value += mspe[0];
				avg_pred_value1 += mspe[1];
				avg_pred_value2 += mspe[2];
			}

#if defined(CHAMELEON_USE_MPI)
			if(MORSE_My_Mpi_Rank() == 0)
			{
#endif
				fprintf(stderr,"Average prediction Error (IDW): %3.9f  -  %3.9f -  %3.9f\n", avg_pred_value, avg_pred_value1, avg_pred_value2);

#if defined(CHAMELEON_USE_MPI)
			}
#endif


			//free memory
			free(Zactual);
			free(Zobs);
			free(Zmiss);
		}
		if(data.mspe ==1)
		{    
			//memory allocation
			Zobs     = (double *) malloc(p*nZobs * sizeof(double));
			Zactual    = (double *) malloc(p*nZmiss * sizeof(double));
			Zmiss    = (double *) malloc(p*nZmiss * sizeof(double));
			if(strcmp (data.computation, "exact") == 0 || strcmp (data.computation, "diag_approx") == 0)
				prediction_init(&data, nZmiss, nZobs, dts, p_grid, q_grid, 1);    
#if defined(EXAGEOSTAT_USE_HICMA)
			else if (strcmp (data.computation, "lr_approx") == 0)
				prediction_init(&data, nZmiss, nZobs, lts, p_grid, q_grid, 1);                        
#endif


			int j = 0;
			for (j = 0; j < pred_samples; j++)
			{
				printf("nZobs = %d\n", p*nZobs);
				if(p==2)
					pick_random_points2(&data, Zobs, Zactual, nZmiss, nZobs, N);
				else
					pick_random_points(&data, Zobs, Zactual, nZmiss, nZobs, N);

				START_TIMING(pred_time);
				//generate_interior_points(&data, Zobs, NULL, nZmiss, nZobs, N);
				if (strcmp (data.computation, "exact") == 0 || strcmp (data.computation, "lr_approx") == 0)
					prediction_error = MORSE_dmle_Predict_Tile(&data, starting_theta, p*nZmiss, p*nZobs, Zobs, Zactual, Zmiss, N);
				else if (strcmp (data.computation, "diag_approx") == 0)
					prediction_error = MORSE_dmle_diag_Predict_Tile(&data, starting_theta, nZmiss, nZobs, Zobs, Zactual, Zmiss, N);
				/*#if defined(EXAGEOSTAT_USE_HICMA)
				  else if (strcmp (data.computation, "lr_approx") == 0)
				  {
				  if(strcmp(arguments.kernel_fun, "univariate_matern_stationary")   == 0)
				  data.hicma_data_type = HICMA_STARSH_PROB_GEOSTAT_POINT;
				  else if(strcmp(arguments.kernel_fun, "bivariate_matern_parsimonious")   == 0)
				  {

				  data.hicma_data_type = HICMA_STARSH_PROB_GEOSTAT_PARSIMONIOUS_BIVARIATE_POINT;

				  }
				  else if(strcmp(arguments.kernel_fun, "bivariate_matern_parsimonious2")   == 0)
				  data.hicma_data_type = HICMA_STARSH_PROB_GEOSTAT_PARSIMONIOUS2_BIVARIATE_POINT;
				  prediction_error = HICMA_dmle_Predict_Tile(&data, starting_theta, nZmiss, nZobs, Zobs, Zactual, Zmiss, N, lts);
				  }
				 */
				//#endif
				STOP_TIMING(pred_time);
#if defined(CHAMELEON_USE_MPI)
				if(MORSE_My_Mpi_Rank() == 0)
				{
#endif				
					int index=0;
					for (index=0; index< nZmiss; index++)
						printf ("(%3.6f, %3.6f)\n ", Zactual[index], Zmiss[index]);

					fprintf(stderr,"Prediction Error: %3.9f \n", prediction_error);
#if defined(CHAMELEON_USE_MPI)
				}
#endif			
				avg_pred_value +=prediction_error;
				avg_pred_value1 +=data.mserror1;
				avg_pred_value2 +=data.mserror2;
			}


			prediction_finalize(&data);
			//free memory
			free(Zactual);
			free(Zobs);
			free(Zmiss);
		}
		char buf[30];
		char str[80];
		strcpy(str, arguments.kernel_fun);
		for(int i=0; i<num_params; i++)
		{

			sprintf(buf, "%0.3f-", initial_theta[i]);
			strcat(str, buf);
		}
		strcat(str, data.computation);
		sprintf(buf, "%0.0f-", data.hicma_acc);
		strcat(str, buf);
		strcat(str, "-theta.txt");
		if(strcmp(arguments.kernel_fun, "bivariate_matern_parsimonious_profile")   == 0)
		{
			starting_theta[0]=data.variance1;
			starting_theta[1]=data.variance2;
		}	
		write_to_estimatedtheta( str, starting_theta, num_params, N/p, pred_time, all_time, (avg_pred_value1/=pred_samples), (avg_pred_value2/=pred_samples), (avg_pred_value/=pred_samples), data.mloe , data.mmom, zvecs);
	}

	print_result(&data, starting_theta, N, zvecs, ncores, lts, test, initial_theta, data.computation, p_grid, q_grid, data.final_loglik, prediction_error);

	if(log == 1 && test == 1)
		finalize_log(&data);


	//nlopt_destroy(opt2);

	if(arguments.profile == 1)
	{
		starpu_fxt_stop_profiling();
		RUNTIME_profiling_display_efficiency();
	}

	MLE_Finalize(&data);
	MORSE_Finalize();
	return 0;
}

